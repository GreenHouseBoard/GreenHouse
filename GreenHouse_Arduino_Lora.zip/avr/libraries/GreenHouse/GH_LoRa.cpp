#include "GH_LoRa.h"
#include "GH_Arduino_Api.h"

void GHArduino::wakeUpLora(){
  printSerial1("",0);//send Enter to wakeup
  Serial.println("\n\rresetting...");
  serial1Rev(1);
  Serial.println();
}
void GHArduino::isAlive(){
  Serial.println();
  Serial.println();
  printSerial1("AT",2);
  Serial.print("lora AT command is: ");
  serial1Rev(0);
}
void GHArduino::sendToSleep(int num){
  Serial.print("lora go to sleep ");
  Serial.print(num);
  Serial.print("s");
  num=num*1000;
  Serial.println();
  printSerial1("AT+SLEEP",8);
  timeWaitSerial(num);
}
//--------------------------------------------------LoRa P2P------------------------------------------------------//
void GHArduino::resetLora(){
  Serial.println("reseting LoRa...");
  digitalWrite(DGHARDUINO_PIN_LORA_POWER,HIGH);
  digitalWrite(DGHARDUINO_PIN_LORA_RESET,HIGH);
  timeWaitSerial(5000);
  Serial.println("Ready!");
}
void GHArduino::setDChannels(uint8_t* myChannels,uint8_t num){
  uint8_t atChannels[12+num] = "AT+CHANNELS=";
  strcat(atChannels, myChannels);
  printSerial1(atChannels,num+12);
  Serial.print("Device Channels set up:");
  serial1Rev(0);
  Serial.println();
}
void GHArduino::setDAddr(uint8_t* myAddr,uint8_t num){
  uint8_t atDaddrp[10+num] = "AT+DADDRP=";
  strcat(atDaddrp, myAddr);
  printSerial1(atDaddrp,10+num);
  Serial.print("Device Address set up:");
  serial1Rev(0);
  Serial.println();
}
void GHArduino::sendPayload_P2P(uint8_t* slaveDAddr,uint8_t num1,uint8_t* payLoad,uint8_t num2){
  uint8_t atSendp[12+num1+num2] = "AT+SENDP=";
  strcat(atSendp, slaveDAddr);
  strcat(atSendp, ":");
  strcat(atSendp, payLoad); 
  printSerial1(atSendp,10+num1+num2);
  Serial.println();
  Serial.print("send payload to slave: ");
  serial1Rev(1);
  Serial.println();
  printSerial1("",0);
}
//------------------------------------------------LoRaWan to getway---------------------------------------------------//
void GHArduino::resetLoRaWan(){
  Serial.println("reseting LoRaWan...");
  digitalWrite(DGHARDUINO_PIN_LORA_POWER,HIGH);
  digitalWrite(DGHARDUINO_PIN_LORA_RESET,HIGH);
}
void GHArduino::joinLora(){
  Serial.println();
  printSerial1("AT+JOIN",7);
  Serial.print("joining to lora: ");
  serial1Rev(0);
}

void GHArduino::sendPayload_GetWay(uint8_t* payLoad,uint8_t num, uint8_t port,uint8_t ack){
  uint8_t atSendp[12+num] = "AT+SEND=";
  char convertChar [16];
  itoa(port, convertChar, 10);
  strcat(atSendp, convertChar);
  strcat(atSendp, ":");
  strcat(atSendp, payLoad);
  strcat(atSendp, ":");
  itoa(ack, convertChar, 10); 
  strcat(atSendp, convertChar);
  printSerial1(atSendp,12+num);
  Serial.println();
  Serial.print("send payload to getway: ");
  serial1Rev(1);
  Serial.println();
}
void GHArduino::serialLoraSetUp() {
uint8_t rfBuf[3]={0,0,0};
while(rfBuf[0] != 98 || rfBuf[1] != 121 || rfBuf[2] != 46){
  if(Serial.available()>0){
    int inByte = Serial.read();
    if((inByte == 0x0D) || (inByte == 0x0A)){
      Serial1.flush();
      Serial1.print("\r"); 
    }else{
       Serial1.print((char)inByte);
       while(1){
        if(Serial.available()>0){
          inByte = Serial.read();
          Serial1.print((char)inByte);
        }
        if((inByte == 0x0D) || (inByte == 0x0A)){
          //Serial1.print("\r"); 
          break;
        }
      }
    }
  }
  if(Serial1.available()){
    int inByte1 = Serial1.read();
    Serial.flush();
    Serial.write(inByte1);
    rfBuf[0]=rfBuf[1];
    rfBuf[1]=rfBuf[2];
    rfBuf[2]=inByte1;
  }
}
}
//----------------------------------------------------private------------------------------------------------------//
void GHArduino::timeWaitSerial(int num){
  unsigned long timer = millis();
  while((unsigned long) (millis() - timer) < num){
        if(Serial1.available()) 
        {
            char inByte1 = Serial1.read();// read from port 1
            //Serial.write(inByte1);
        }
   }
   timer = millis();
}

void GHArduino::printSerial1(uint8_t* data,uint8_t num){
  for(int i = 0;i<num;i++){
    Serial1.flush();
    Serial1.print((char)data[i]);
  }
  Serial1.flush();
  Serial1.print("\r");
}
void GHArduino::serial1Rev(int ack){
  uint8_t rfBuf[2]={0,0};
  unsigned long timer = millis();
  int i = 1;
  int checkOk = 0;
  while((unsigned long) (millis() - timer) < 10000){
    if(Serial1.available()>0){
    int inByte = Serial1.read();// read from port 1   
    //Serial.write(inByte);
      if((inByte >= 0x20) && (inByte <= 0x7f)){
        rfBuf[1]=inByte;
      }
    }
    if(ack==0){
      if((rfBuf[0]==79)&&(rfBuf[1]==75)){//check ok
        Serial.print("OK");
        checkOk = 1;
        break;
      }
    }
   if(ack==1){//check P2P Signal Receive Standby.
      if((rfBuf[0]==121)&&(rfBuf[1]==46)){//check ok
        Serial.print("OK");
        //Serial.print("P2P Signal Receive Standby.");
        checkOk = 1;
        break;
      }
   }
     rfBuf[0]=rfBuf[1];
  }
  if(checkOk == 0){
    Serial.print("ERROR");
  }
  timer = millis();
}
