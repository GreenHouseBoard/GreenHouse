#ifndef LoRaWan_Getway_h
#define LoRaWan_Getway_h
#include <Arduino.h>
#include <string.h>
void resetLora();//reset module by set High pin 6 and pin 7
void healthCheckLora();// chect AT command.
void joinLora();// join to send payload.
void sendPayload(String payLoad, int port,int ack);// send payload with port 2 and ack 1.
void sendToSleep();//lora go to sleep(30s).
void OffAndOnLora();// reset lora.
void serial1Rev();// Serial1 get data
void serialLoraSet();//LoRaWan set via serial.
#endif
