#ifndef LORAWAN_P2P_h
#define LORAWAN_P2P_h
#include <Arduino.h>
class GHArduino{
public:
  void isAlive();// chect AT command.
  void sendToSleep(int num);//lora go to sleep(30s).
  void wakeUpLora();//LoRaWan set via serial.
  //------------------------------------------------------LoRa P2P----------------------------------------------//
  void resetLora();//reset module by set High pin 6 and pin 7
  void setDChannels(uint8_t* myChannels,uint8_t num);// set Device Channels
  void setDAddr(uint8_t* myAddr,uint8_t num);//set Device Address
  void sendPayload_P2P(uint8_t* slaveDAddr,uint8_t num1,uint8_t* payLoad,uint8_t num2);//send payload to slave.
  //------------------------------------------------LoRaWAN to getway--------------------------------------------//
  void resetLoRaWan();//reset module by set High pin 6 and pin 7
  void joinLora();//join LoRa
  void sendPayload_GetWay(uint8_t* payLoad,uint8_t num, uint8_t port,uint8_t ack);// send payload to getway with port 2 and ack 1.
  void serialLoraSetUp();//LoRaWan set via serial.
  //------------------------------------------------private--------------------------------------------//
private:
  void timeWaitSerial(int num);//wait serial1
  void printSerial1(uint8_t* data,uint8_t num);//print via serial1
  void serial1Rev(int ack);// Serial1 get data
};
#endif /* LORAWAN_P2P_h */
