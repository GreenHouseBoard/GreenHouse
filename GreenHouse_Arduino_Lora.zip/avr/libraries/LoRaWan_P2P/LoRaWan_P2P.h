#ifndef LoRaWan_P2P_h
#define LoRaWan_P2P_h
#include <Arduino.h>
#include <string.h>
void resetLora();//reset module by set High pin 6 and pin 7
void setDChannels(String DChannels);// set Device Channels
void setDAddr(String DAddr);//set Device Address
void healthCheckLora();// chect AT command.
void sendPayload(String STDAddr, String payLoad);//send payload to slave.
void sendToSleep();//lora go to sleep(30s).
void serial1Rev();// Serial1 get data
void OffAndOnLora();//LoRaWan set via serial.
#endif
