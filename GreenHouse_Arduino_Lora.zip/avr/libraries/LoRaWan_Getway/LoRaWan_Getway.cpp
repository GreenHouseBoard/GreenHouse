#include "LoRaWan_Getway.h"

void resetLora(){
  digitalWrite(6,HIGH);
  delay(1000);
  digitalWrite(7,HIGH);
}
void OffAndOnLora(){
  Serial.println("\n\rreset.");
  digitalWrite(7,LOW);
  digitalWrite(6,LOW);
  delay(1000);
  digitalWrite(6,HIGH);
  digitalWrite(7,HIGH);
  delay(1000);
  Serial1.flush();
  Serial1.print("\r");
  Serial1.flush();
  Serial1.print("0");
  Serial1.flush();
  Serial1.print("\r");
}
void healthCheckLora(){
  Serial.println();
  Serial1.flush();
  Serial1.print("AT");
  Serial1.flush();
  Serial1.print("\r");
  Serial1.flush();
  delay(100);
  Serial.print("lora AT command is: ");
  serial1Rev();
}
void joinLora(){
  Serial.println();
  Serial1.flush();
  Serial1.print("AT+JOIN");
  Serial1.flush();
  Serial1.print("\r");
  Serial1.flush();
  delay(100);
  Serial.print("joining to lora: ");
  serial1Rev();
  Serial.println();
}
void sendPayload(String payLoad, int port,int ack){
  Serial1.flush();
  Serial1.print("AT+SEND=");
  Serial1.flush();
  Serial1.print(port);
  Serial1.flush();
  Serial1.print(":");
  Serial1.flush();
  Serial1.print(payLoad);
  Serial1.flush();
  Serial1.print(":");
  Serial1.flush();
  Serial1.print(ack);
  Serial1.flush();
  Serial1.print("\r");
  Serial1.flush();
  delay(100);
  Serial.print("send '");
  Serial.print(payLoad);
  Serial.print("' to lora: ");
  serial1Rev();
  Serial.println();
}
void sendToSleep(){
  Serial1.flush();
  Serial1.print("AT+SLEEP");
  Serial1.flush();
  Serial1.print("\r");
  Serial1.flush();
  delay(100);
  Serial.print("lora sleep: ");
  serial1Rev();
  Serial.println();
  delay(30000);
}
void serial1Rev(){
  String rfBuf;
  unsigned long timer = millis();
  getRfBuf:
  while(Serial1.available()>0){
    int inByte = Serial1.read();// read from port 1   
    Serial.flush();
    //Serial.write(inByte);
    if((inByte >= 0x20) && (inByte <= 0x7f))
    {
      rfBuf.concat((char)inByte);
    }
  }
  int checkRfBuf = 0;
  if(rfBuf.indexOf("OK", 0)>0){
      Serial.print("OK");
      checkRfBuf=1;
    }
  if(rfBuf.indexOf("AT_ERROR", 0)>0){
      Serial.print("ERROR");
      checkRfBuf=1;
    }
  if(checkRfBuf==0){
      if((unsigned long) (millis() - timer) < 30000){
        goto getRfBuf;
      }else{
        Serial.print("ERROR");
        timer = millis();
      } 
    }
}
void serialLoraSet() {
  String pcBuf;
  String rfBuf;
  checkSerial:
  if(Serial.available()>0){
    int inByte = Serial.read();
    if((inByte >= 0x20) && (inByte <= 0x7f))
    {
      pcBuf.concat((char)inByte);
    }
    if((inByte == 0x0D) || (inByte == 0x0A))
    {
        Serial1.flush();
        Serial1.print(pcBuf);
        Serial1.flush();
        Serial1.print("\r");
        Serial1.flush();
        pcBuf.remove(0);
    }else{
      goto checkSerial;
    }
  }
  if(Serial1.available()){
    int inByte = Serial1.read();// read from port 1   
    Serial.flush();
    Serial.write(inByte);
    if((inByte >= 0x20) && (inByte <= 0x7f))
    {
      rfBuf.concat((char)inByte);
    }
  }
    if(rfBuf.indexOf("P2P Signal Receive Standby.", 0)>0){
      rfBuf.remove(0);
    }else{
      if(rfBuf.indexOf("0.", 0)>0){
        rfBuf.remove(0);
      }
      goto checkSerial; 
    }
}
